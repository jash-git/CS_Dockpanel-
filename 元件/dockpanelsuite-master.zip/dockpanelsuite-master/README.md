DockPanel Suite
===============

[![Join the chat at https://gitter.im/dockpanelsuite/dockpanelsuite](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/dockpanelsuite/dockpanelsuite?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
[![NuGet Version](https://img.shields.io/nuget/v/DockPanelSuite.svg?style=flat)](https://www.nuget.org/packages/DockPanelSuite/)
[![Build status](https://ci.appveyor.com/api/projects/status/tpn4i42s6wv2xupn?svg=true)](https://ci.appveyor.com/project/lextm/dockpanelsuite)
[![Stories in Ready](https://badge.waffle.io/dockpanelsuite/dockpanelsuite.svg?label=ready&title=Ready)](http://waffle.io/dockpanelsuite/dockpanelsuite) 

DockPanel Suite - The Visual Studio inspired docking library for .NET WinForms

For more details, check out [http://dockpanelsuite.com](http://dockpanelsuite.com).