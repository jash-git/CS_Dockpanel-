﻿using System.Windows.Forms;

namespace DockSample
{
    public partial class SplashScreen : Form
    {
        public SplashScreen()
        {
            InitializeComponent();
        }
    }
}
